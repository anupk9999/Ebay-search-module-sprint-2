package Pages;

import org.openqa.selenium.By;

import Browser.Browser;
import Locators.locators;

public class Product_addtocart extends Browser {

//	public static void addtocart()  {
//		//driver.findElement(By.xpath("//*[@id='isCartBtn_btn']")).click();//add to cart
//		locators.addtocart();
//	}
}
