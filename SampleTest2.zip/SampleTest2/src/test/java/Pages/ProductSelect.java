package Pages;

import Browser.Browser;
import Locators.locators;

public class ProductSelect extends Browser{

	public static void ProductSelection() {
		//locators.ProductSelection();
		//locators.Product_List();
	}
}
